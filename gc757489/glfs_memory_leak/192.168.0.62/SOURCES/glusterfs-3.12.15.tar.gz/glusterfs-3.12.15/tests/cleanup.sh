#!/bin/bash

. $(dirname $0)/include.rc
cleanup
